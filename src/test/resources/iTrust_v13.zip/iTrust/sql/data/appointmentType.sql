INSERT INTO appointmenttype(appt_type,duration)
VALUES
('General Checkup', '45'),
('Mammogram', '60'),
('Physical', '15'),
('Colonoscopy', '90'),
('Ultrasound', '30'),
('Consultation', '30');