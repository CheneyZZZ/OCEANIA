INSERT INTO ReportRequests
(ID,RequesterMID,PatientMID,RequestedDate,ViewedDate,Status)
VALUES
(1,9000000000,2,'2008-01-01 12:00',null,'Requested'),
(2,9000000000,2,'2008-01-02 12:00',null,'Requested'),
(3,9000000000,2,'2008-01-03 12:00',null,'Requested'),
(4,9000000000,2,'2008-01-04 12:00','2008-03-04 12:00','Viewed'),
(5,9000000000,1,'2008-01-05 12:00',null,'Requested'),
(6,9000000000,1,'2008-06-01 12:00',null,'Requested'),
(7,9000000002,3,'2008-01-04 12:00','2008-03-04 12:00','Viewed');
