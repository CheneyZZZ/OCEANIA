INSERT INTO Personnel(
MID,
AMID,
role,
lastName, 
firstName, 
address1,
address2,
city,
state,
zip,
zip1,
zip2,
phone,
phone1,
phone2,
phone3,
specialty,
email)
VALUES (
9000000006,
null,
'er',
'Time',
'Justin',
'555 Wanahakalugi',
'',
'Honolulu',
'HI',
'96801',
'96801',
'',
'135-246-3579',
'123',
'246',
'3579',
'',
'jtime@iTrust.or'
);

INSERT INTO Users(MID, password, role, sQuestion, sAnswer) VALUES(9000000006, 'pw', 'er', 'first letter?', 'a');

