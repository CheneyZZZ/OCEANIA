INSERT INTO RemoteMonitoringData(PatientID, systolicBloodPressure, diastolicBloodPressure, glucoseLevel, timeLogged, ReporterRole, ReporterID) 
                    VALUES 	(2, 120, 80, 100, '2009-11-13 05:30:00', "self-reported", 1),
                    		(2, 110, 60, 110, '2009-11-14 05:30:00', "self-reported", 1),
                    		(2, 120, 70, 120, '2009-11-15 05:30:00', "self-reported", 1),
                    		(2, 115, 80, 130, '2009-11-16 05:30:00', "self-reported", 1),
                    		(2, 110, 75, 140, '2009-11-18 05:30:00', "self-reported", 1);