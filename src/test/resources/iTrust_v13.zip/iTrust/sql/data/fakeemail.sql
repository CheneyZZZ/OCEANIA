INSERT INTO FakeEmail (ToAddr, FromAddr, Subject,Body, AddedDate) 
values ('gstormcrow@iTrust.org','noreply@itrust.com', 'this is an email', 'hello world', '2007-06-23 06:55:59'),
('gstormcrow@iTrust.org,kdoctor@iTrust.org','noreply@itrust.com', 'this is another email', 'hello earth', '2007-06-23 06:55:58'),
('andy.programmer@gmail.com','noreply@itrust.com', 'this is another email', 'your appendix is fine','2007-06-23 06:55:57'),
('andy.programmer@gmail.com','noreply@itrust.com', 'this is another email', 'come see us ASAP','2007-06-23 06:55:56');